package test1;

public class z11 {
	
	public static int i = 1;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(i);
	}

}
